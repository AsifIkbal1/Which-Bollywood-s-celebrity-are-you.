# which-bollywood-celebrity-are-you
A streamlit web app which can tell with which bollywood celebrity you face resembles
